package brazorobotico2;

import java.util.Scanner;

public class BrazoRobotico2 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        double L1 = 30.0; // Longitud del brazo conectado al suelo
        double L2 = 20.0; // Longitud del brazo del codo
        
        System.out.print("Ingrese el angulo del hombro θ (en grados): ");
        double thetaGrados = scanner.nextDouble();
        
        // Solicitar el ángulo φ del codo
        System.out.print("Ingrese el angulo del codo φ (en grados): ");
        double phiGrados = scanner.nextDouble();
        
        // Convertir los ángulos de grados a radianes
        double thetaRadianes = Math.toRadians(thetaGrados);
        double phiRadianes = Math.toRadians(phiGrados);
        
        // Calcular la posición del codo (x_c, y_c)
        double x_c = L1 * Math.cos(thetaRadianes);
        double y_c = L1 * Math.sin(thetaRadianes);
        
        System.out.printf("Posición del codo: (%.2f cm, %.2f cm)%n", x_c, y_c);
        
        // Calcular la posición de la mano (x_m, y_m)
        double x_m = x_c + L2 * Math.cos(thetaRadianes + phiRadianes);
        double y_m = y_c + L2 * Math.sin(thetaRadianes + phiRadianes);
        
        System.out.printf("Posicion de la mano: (%.2f cm, %.2f cm)%n", x_m, y_m);
        
        scanner.close();
    }
}